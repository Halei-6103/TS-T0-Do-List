window.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("todo-form") as HTMLFormElement;
    const input = document.getElementById("new-task") as HTMLInputElement;
    const list = document.getElementById("task-list") as HTMLUListElement;
  
    form.addEventListener("submit", (e: Event) => {
      e.preventDefault();
      const task = input.value.trim();
      if (task === "") return;
  
      const li = document.createElement("li");
      li.textContent = task;
  
      li.addEventListener("click", () => {
        li.classList.toggle("completed");
      });
  
      const btn = document.createElement("button");
      btn.textContent = "Delete";
      btn.addEventListener("click", (e: MouseEvent) => {
        e.stopPropagation();
        li.remove();
      });
  
      li.appendChild(btn);
      list.appendChild(li);
      input.value = "";
    });
  });
  