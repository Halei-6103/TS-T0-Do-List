window.addEventListener("DOMContentLoaded", () => { //buffer so the buttons can load
  //references to the inputs and task elements
    const form = document.getElementById("todo-form") as HTMLFormElement;
    const input = document.getElementById("new-task") as HTMLInputElement;
    const list = document.getElementById("task-list") as HTMLUListElement;
    //handles the submission when the user adds a new task
    form.addEventListener("submit", (e: Event) => {
      e.preventDefault(); //Doesn't let the page refresh when we click add for a task
      const task = input.value.trim();
      if (task === "") return; //Doesn't allow empty tasks
  
      //Class is completed when clicked
      const li = document.createElement("li");
      li.textContent = task;
      
      //Class is completed when clicked
      li.addEventListener("click", () => {
        li.classList.toggle("completed");
      });

      //Creates the delete button
      const btn = document.createElement("button");
      btn.textContent = "Delete";

      //Removes the task when delete button is clicked
      btn.addEventListener("click", (e: MouseEvent) => {
        e.stopPropagation(); //Prevents hitting "Completed" again
        li.remove(); //Gets rid of the task
      });
  
      //Add the delete button
      li.appendChild(btn);
      //Add the task to the list
      list.appendChild(li);
      //Clear inputs
      input.value = "";
    });
  });
  